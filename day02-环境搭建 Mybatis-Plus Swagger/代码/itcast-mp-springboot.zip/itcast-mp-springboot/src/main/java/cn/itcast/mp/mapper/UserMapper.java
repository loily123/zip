package cn.itcast.mp.mapper;

import cn.itcast.mp.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * Created by Administrator.
 */
public interface UserMapper extends BaseMapper<User> {

    public User findById(Long id);
}
