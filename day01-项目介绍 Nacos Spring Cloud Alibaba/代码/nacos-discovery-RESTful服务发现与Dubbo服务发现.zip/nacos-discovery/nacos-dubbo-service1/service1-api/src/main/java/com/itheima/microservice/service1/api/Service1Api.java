package com.itheima.microservice.service1.api;

/**
 * Created by Administrator.
 */
public interface Service1Api {
    public String dubboService1();
}
