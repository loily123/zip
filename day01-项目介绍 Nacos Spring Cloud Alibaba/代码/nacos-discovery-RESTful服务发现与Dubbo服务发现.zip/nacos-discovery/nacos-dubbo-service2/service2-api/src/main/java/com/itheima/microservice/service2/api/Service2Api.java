package com.itheima.microservice.service2.api;

/**
 * Created by Administrator.
 */
public interface Service2Api {
    public String dubboService2();
}
